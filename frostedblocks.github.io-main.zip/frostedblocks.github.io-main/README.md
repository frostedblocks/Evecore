# FrostedBlocks

A modern crypto prices dashboard + AI chat + hardware wallet affiliate store.

## Live Site
https://frostedblocks.com

## Features
- Real-time crypto prices (CoinGecko)
- FrostedAI - Groq-powered crypto chatbot
- Hardware wallet store (Ledger, Trezor, etc.)
- Crypto news aggregator
- Dedicated pages for major coins (Cardano, XRP, ICP, etc.)

## Tech Stack
- Static HTML + Tailwind CSS
- GitHub Pages hosting
- Groq API for AI chat
- Python script + GitHub Actions for price caching

## Repository Structure
- `index.html` - Main prices dashboard
- `ai.html` - FrostedAI chat
- `/store/` - Affiliate store
- Various coin insight pages

Made with ❄️ by FrostedBlocks team.