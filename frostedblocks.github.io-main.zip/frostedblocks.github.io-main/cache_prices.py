# !/usr/bin/env python3
import requests
import json
from datetime import datetime, timezone

def cache_prices():
    coins = ['bitcoin', 'ethereum', 'solana', 'cardano']
    
    try:
        url = "https://api.coingecko.com/api/v3/simple/price"
        params = {
            'ids': ','.join(coins),
            'vs_currencies': 'usd',
            'include_24hr_change': 'true'
        }
        
        response = requests.get(url, params=params, timeout=15)
        response.raise_for_status()
        data = response.json()
        
        # Add timestamp
        data['last_updated'] = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
        
        # Save to file
        with open('prices.json', 'w') as f:
            json.dump(data, f, indent=2)
        
        print(f"✅ Prices cached successfully at {data['last_updated']}")
        
    except Exception as e:
        print(f"❌ Error caching prices: {e}")

if __name__ == "__main__":
    cache_prices()
